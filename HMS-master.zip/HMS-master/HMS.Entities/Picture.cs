﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Entities
{
    public class Picture
    {
        public int ID { get; set; }

        public string URL { get; set; }
    }
}
