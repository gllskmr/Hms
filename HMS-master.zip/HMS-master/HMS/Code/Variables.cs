﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HMS.Code
{
    public class Variables
    {
        public const string HotelFullName = "Sakhir International Resort";
        public const string HotelShortName = "Sakhir";
        public const string HotelNameAbbreviate = "SIR";
    }
}